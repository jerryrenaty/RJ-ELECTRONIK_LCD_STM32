/*
 * RJ_ELEKTRONIK_HX711_LCD.c
 *
 *  Created on: Apr 6, 2025
 *      Author: renat
 */

#include "RJ_ELEKTRONIK_LCD_STM32.h"
#include <stdio.h>
#include <string.h>
#include "main.h"

/* Variables statiques pour stocker la configuration des pins */
static GPIO_TypeDef* RS_Port;
static uint16_t RS_Pin;
static GPIO_TypeDef* RW_Port;
static uint16_t RW_Pin;
static GPIO_TypeDef* EN_Port;
static uint16_t EN_Pin;
static GPIO_TypeDef* D4_Port;
static uint16_t D4_Pin;
static GPIO_TypeDef* D5_Port;
static uint16_t D5_Pin;
static GPIO_TypeDef* D6_Port;
static uint16_t D6_Pin;
static GPIO_TypeDef* D7_Port;
static uint16_t D7_Pin;

/* Fonctions privées */

/**
  * @brief Active le signal Enable du LCD
  */
static void LCD_Enable(void) {
    HAL_GPIO_WritePin(EN_Port, EN_Pin, GPIO_PIN_RESET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(EN_Port, EN_Pin, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(EN_Port, EN_Pin, GPIO_PIN_RESET);
    HAL_Delay(1);
}

/**
  * @brief Envoie 4 bits de données au LCD
  * @param data: Les 4 bits à envoyer (dans les 4 LSB)
  */
static void LCD_Write4Bits(uint8_t data) {
    HAL_GPIO_WritePin(D4_Port, D4_Pin, (data & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(D5_Port, D5_Pin, (data & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(D6_Port, D6_Pin, (data & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(D7_Port, D7_Pin, (data & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    LCD_Enable();
}

/**
  * @brief Envoie une commande ou des données au LCD
  * @param data: Byte à envoyer
  * @param rs: 0 pour commande, 1 pour données
  */
static void LCD_Write(uint8_t data, uint8_t rs) {
    HAL_GPIO_WritePin(RS_Port, RS_Pin, rs ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(RW_Port, RW_Pin, GPIO_PIN_RESET);
    LCD_Write4Bits(data >> 4);  // Envoi des 4 bits de poids fort
    LCD_Write4Bits(data);       // Envoi des 4 bits de poids faible
}

/* Fonctions publiques */

/**
  * @brief Initialise le LCD avec la configuration des pins
  * @param rs_port, rs_pin: Port/Pin pour RS
  * @param rw_port, rw_pin: Port/Pin pour RW
  * @param en_port, en_pin: Port/Pin pour EN
  * @param d4_port, d4_pin: Port/Pin pour D4
  * @param d5_port, d5_pin: Port/Pin pour D5
  * @param d6_port, d6_pin: Port/Pin pour D6
  * @param d7_port, d7_pin: Port/Pin pour D7
  */
void LCD_Init(
    GPIO_TypeDef* rs_port, uint16_t rs_pin,
    GPIO_TypeDef* rw_port, uint16_t rw_pin,
    GPIO_TypeDef* en_port, uint16_t en_pin,
    GPIO_TypeDef* d4_port, uint16_t d4_pin,
    GPIO_TypeDef* d5_port, uint16_t d5_pin,
    GPIO_TypeDef* d6_port, uint16_t d6_pin,
    GPIO_TypeDef* d7_port, uint16_t d7_pin
) {
    /* Sauvegarde des paramètres */
    RS_Port = rs_port; RS_Pin = rs_pin;
    RW_Port = rw_port; RW_Pin = rw_pin;
    EN_Port = en_port; EN_Pin = en_pin;
    D4_Port = d4_port; D4_Pin = d4_pin;
    D5_Port = d5_port; D5_Pin = d5_pin;
    D6_Port = d6_port; D6_Pin = d6_pin;
    D7_Port = d7_port; D7_Pin = d7_pin;

    /* Configuration des GPIO */
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;

    /* Initialisation des broches */
    GPIO_InitStruct.Pin = RS_Pin;
    HAL_GPIO_Init(RS_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = RW_Pin;
    HAL_GPIO_Init(RW_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = EN_Pin;
    HAL_GPIO_Init(EN_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = D4_Pin;
    HAL_GPIO_Init(D4_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = D5_Pin;
    HAL_GPIO_Init(D5_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = D6_Pin;
    HAL_GPIO_Init(D6_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = D7_Pin;
    HAL_GPIO_Init(D7_Port, &GPIO_InitStruct);

    /* Initialisation du LCD */
    HAL_Delay(50);  // Attente après alimentation

    /* Séquence d'initialisation */
    HAL_GPIO_WritePin(RS_Port, RS_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(RW_Port, RW_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(EN_Port, EN_Pin, GPIO_PIN_RESET);

    LCD_Write4Bits(0x03);
    HAL_Delay(5);
    LCD_Write4Bits(0x03);
    HAL_Delay(1);
    LCD_Write4Bits(0x03);
    LCD_Write4Bits(0x02);  // Passage en mode 4 bits

    /* Configuration du LCD */
    LCD_SendCommand(LCD_FUNCTION_SET | LCD_4BIT_MODE | LCD_2LINE | LCD_5x8DOTS);
    LCD_SendCommand(LCD_DISPLAY_CONTROL | LCD_DISPLAY_ON | LCD_CURSOR_OFF | LCD_BLINK_OFF);
    LCD_SendCommand(LCD_CLEAR_DISPLAY);
    HAL_Delay(2);
    LCD_SendCommand(LCD_ENTRY_MODE_SET | LCD_ENTRY_LEFT);
}

/**
  * @brief Envoie une commande au LCD
  * @param cmd: Commande à envoyer
  */
void LCD_SendCommand(uint8_t cmd) {
    LCD_Write(cmd, 0);
}

/**
  * @brief Envoie des données au LCD
  * @param data: Donnée à envoyer
  */
void LCD_SendData(uint8_t data) {
    LCD_Write(data, 1);
}

/**
  * @brief Affiche une chaîne de caractères sur le LCD
  * @param str: Pointeur vers la chaîne à afficher
  */
void LCD_SendString(char *str) {
    while (*str) {
        LCD_SendData(*str++);
    }
}

/**
  * @brief Positionne le curseur à une position spécifique
  * @param row: Ligne (0 à 3)
  * @param column: Colonne (0 à 15 pour 16x2)
  */
void LCD_SetCursor(uint8_t row, uint8_t column) {
    uint8_t address;

    switch (row) {
        case 0: address = 0x00 + column; break;
        case 1: address = 0x40 + column; break;
        case 2: address = 0x14 + column; break;
        case 3: address = 0x54 + column; break;
        default: address = 0x00 + column;
    }
    LCD_SendCommand(LCD_SET_DDRAM_ADDR | address);
}

/**
  * @brief Efface l'écran et positionne le curseur en haut à gauche
  */
void LCD_Clear(void) {
    LCD_SendCommand(LCD_CLEAR_DISPLAY);
    HAL_Delay(2);
}

/**
  * @brief Positionne le curseur en haut à gauche sans effacer l'écran
  */
void LCD_Home(void) {
    LCD_SendCommand(LCD_RETURN_HOME);
    HAL_Delay(2);
}
/**
  * @brief  Turns the display on
  */
void LCD_DisplayOn(void) {
    LCD_SendCommand(LCD_DISPLAY_CONTROL | LCD_DISPLAY_ON);
}

/**
  * @brief  Turns the display off
  */
void LCD_DisplayOff(void) {
    LCD_SendCommand(LCD_DISPLAY_CONTROL | LCD_DISPLAY_OFF);
}

/**
  * @brief  Turns the cursor on
  */
void LCD_CursorOn(void) {
    LCD_SendCommand(LCD_DISPLAY_CONTROL | LCD_DISPLAY_ON | LCD_CURSOR_ON);
}

/**
  * @brief  Turns the cursor off
  */
void LCD_CursorOff(void) {
    LCD_SendCommand(LCD_DISPLAY_CONTROL | LCD_DISPLAY_ON | LCD_CURSOR_OFF);
}

/**
  * @brief  Turns cursor blinking on
  */
void LCD_BlinkOn(void) {
    LCD_SendCommand(LCD_DISPLAY_CONTROL | LCD_DISPLAY_ON | LCD_BLINK_ON);
}

/**
  * @brief  Turns cursor blinking off
  */
void LCD_BlinkOff(void) {
    LCD_SendCommand(LCD_DISPLAY_CONTROL | LCD_DISPLAY_ON | LCD_BLINK_OFF);
}

/**
  * @brief  Scrolls display to the left
  */
void LCD_ScrollLeft(void) {
    LCD_SendCommand(LCD_CURSOR_SHIFT | 0x08);
}

/**
  * @brief  Scrolls display to the right
  */
void LCD_ScrollRight(void) {
    LCD_SendCommand(LCD_CURSOR_SHIFT | 0x0C);
}

/**
  * @brief  Creates a custom character
  * @param  location: CGRAM location (0-7)
  * @param  charmap: Array of 8 bytes defining the character
  */
void LCD_CustomChar(uint8_t location, uint8_t charmap[]) {
    location &= 0x7; // Limit to 0-7
    LCD_SendCommand(LCD_SET_CGRAM_ADDR | (location << 3));

    for (uint8_t i = 0; i < 8; i++) {
        LCD_SendData(charmap[i]);
    }
}

/**
  * @brief  Prints an integer number
  * @param  num: Number to print
  */
void LCD_PrintNumber(int num) {
    char buffer[12];
    snprintf(buffer, sizeof(buffer), "%d", num);
    LCD_SendString(buffer);
}

/**
  * @brief  Prints a floating point number
  * @param  num: Number to print
  * @param  decimals: Number of decimal places
  */
void LCD_PrintFloat(float num, uint8_t decimals) {
    char format[10];
    snprintf(format, sizeof(format), "%%.%df", decimals);

    char buffer[20];
    snprintf(buffer, sizeof(buffer), format, num);
    LCD_SendString(buffer);
}
/**
  * @brief  Démonstration complète de toutes les fonctionnalités LCD
  * @param  delay_ms: Durée d'affichage pour chaque démo (en ms)
  */
void LCD_FullDemo(uint32_t delay_ms) {
    // 1. INITIALISATION
    LCD_Init(GPIOA, GPIO_PIN_0, GPIOA, GPIO_PIN_1, GPIOA, GPIO_PIN_2,
             GPIOA, GPIO_PIN_3, GPIOA, GPIO_PIN_4, GPIOA, GPIO_PIN_5, GPIOA, GPIO_PIN_6);

    // 2. DÉMO BASIQUE
    LCD_Clear();
    LCD_SendString("Fonctions de base");
    LCD_SetCursor(1, 0);
    LCD_SendString("Clear/Home/Text");
    HAL_Delay(delay_ms);

    // 3. DÉMO CURSEUR ET CLIGNOTEMENT
    LCD_Clear();
    LCD_SendString("Curseur ON");
    LCD_SetCursor(1, 0);
    LCD_SendString("Clignotement ON");
    LCD_CursorOn();
    LCD_BlinkOn();
    HAL_Delay(delay_ms);
    LCD_CursorOff();
    LCD_BlinkOff();

    // 4. DÉMO AFFICHAGE ON/OFF
    LCD_Clear();
    LCD_SendString("Display OFF/ON");
    HAL_Delay(delay_ms/2);
    LCD_DisplayOff();
    HAL_Delay(delay_ms);
    LCD_DisplayOn();
    HAL_Delay(delay_ms/2);

    // 5. DÉMO CARACTÈRES SPÉCIAUX
    LCD_Clear();
    // Création de 3 caractères custom (emplacements 0-7)
    uint8_t heart[8] = {0x00,0x0A,0x1F,0x1F,0x0E,0x04,0x00,0x00};  // Cœur
    uint8_t bell[8]  = {0x04,0x0E,0x0E,0x0E,0x1F,0x00,0x04,0x00};  // Cloche
    uint8_t note[8]  = {0x02,0x03,0x02,0x0E,0x1E,0x0C,0x00,0x00}; // Note

    LCD_CustomChar(0, heart);
    LCD_CustomChar(1, bell);
    LCD_CustomChar(2, note);

    LCD_SendString("Custom: ");
    LCD_SendData(0); // Cœur
    LCD_SendData(1); // Cloche
    LCD_SendData(2); // Note
    LCD_SetCursor(1, 0);
    LCD_SendString("Codes: 0 1 2");
    HAL_Delay(delay_ms);

    // 6. DÉMO NOMBRES
    LCD_Clear();
    LCD_SendString("Nombres:");
    LCD_SetCursor(1, 0);
    LCD_PrintNumber(-123);   // Entier négatif
    LCD_SendString(" ");
    LCD_PrintNumber(42);     // Entier positif
    HAL_Delay(delay_ms/2);

    LCD_Clear();
    LCD_SendString("Flottants:");
    LCD_SetCursor(1, 0);
    LCD_PrintFloat(3.14159, 4);  // Pi avec 4 décimales
    LCD_SendString(" ");
    LCD_PrintFloat(-2.5, 1);     // Négatif avec 1 décimale
    HAL_Delay(delay_ms);

    // 7. DÉMO DÉFILEMENT
    LCD_Clear();
    LCD_SendString("Defilement:");
    LCD_SetCursor(1, 0);
    LCD_SendString("<-- Gauche -->");
    HAL_Delay(delay_ms);

    // Défilement vers la gauche
    for(uint8_t i=0; i<16; i++) {
        LCD_ScrollLeft();
        HAL_Delay(500);
    }
    HAL_Delay(delay_ms);

    // Défilement vers la droite
    for(uint8_t i=0; i<16; i++) {
        LCD_ScrollRight();
        HAL_Delay(300);
    }
    HAL_Delay(delay_ms);

    // 8. DÉMO COMBINÉE (SCENARIO COMPLET)
    LCD_Clear();
    LCD_SendString("Scenario complet");

    // Animation curseur
    for(uint8_t i=0; i<3; i++) {
        LCD_SetCursor(1, 0);
        LCD_CursorOn();
        HAL_Delay(500);
        LCD_CursorOff();
        HAL_Delay(500);
    }

    // Affichage progressif
    char text[] = "Tous tests OK! ";
    LCD_SetCursor(1, 0);
    for(uint8_t i=0; i<strlen(text); i++) {
        LCD_SendData(text[i]);
        HAL_Delay(500);
    }

    // Clignotement final
    for(uint8_t i=0; i<4; i++) {
        LCD_DisplayOff();
        HAL_Delay(500);
        LCD_DisplayOn();
        HAL_Delay(500);
    }

    // Fin
    LCD_Clear();
    LCD_SendString("Demo terminee!");
    LCD_SetCursor(1, 0);
    LCD_SendString(":) ");
    LCD_SendData(0); // Affiche le cœur
}
