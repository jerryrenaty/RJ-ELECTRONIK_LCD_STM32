/**
  * @file    RJ_ELEKTRONIK_HX711_LCD.h
  * @brief   Header file for LCD controller using 4-bit interface
  * @author  renat
  * @date    Apr 6, 2025
  */

#ifndef INC_RJ_ELEKTRONIK_HX711_LCD_H_
#define INC_RJ_ELEKTRONIK_HX711_LCD_H_

#include "stm32f1xx_hal.h"

/* LCD Command Definitions ---------------------------------------------------*/

/** Clear display command */
#define LCD_CLEAR_DISPLAY   0x01

/** Return home command */
#define LCD_RETURN_HOME     0x02

/** Entry mode set command */
#define LCD_ENTRY_MODE_SET  0x04

/** Display control command */
#define LCD_DISPLAY_CONTROL 0x08

/** Cursor shift command */
#define LCD_CURSOR_SHIFT    0x10

/** Function set command */
#define LCD_FUNCTION_SET    0x20

/** Set CGRAM address command */
#define LCD_SET_CGRAM_ADDR  0x40

/** Set DDRAM address command */
#define LCD_SET_DDRAM_ADDR  0x80

/* Entry Mode Options --------------------------------------------------------*/

/** Cursor moves to right */
#define LCD_ENTRY_RIGHT          0x00

/** Cursor moves to left */
#define LCD_ENTRY_LEFT           0x02

/** Display shift on */
#define LCD_ENTRY_SHIFT_INCREMENT 0x01

/** Display shift off */
#define LCD_ENTRY_SHIFT_DECREMENT 0x00

/* Display Control Options ---------------------------------------------------*/

/** Turn display on */
#define LCD_DISPLAY_ON  0x04

/** Turn display off */
#define LCD_DISPLAY_OFF 0x00

/** Turn cursor on */
#define LCD_CURSOR_ON   0x02

/** Turn cursor off */
#define LCD_CURSOR_OFF  0x00

/** Turn blinking on */
#define LCD_BLINK_ON    0x01

/** Turn blinking off */
#define LCD_BLINK_OFF   0x00

/* Function Set Options ------------------------------------------------------*/

/** 8-bit interface */
#define LCD_8BIT_MODE 0x10

/** 4-bit interface */
#define LCD_4BIT_MODE 0x00

/** 2-line display */
#define LCD_2LINE     0x08

/** 1-line display */
#define LCD_1LINE     0x00

/** 5x10 dots character font */
#define LCD_5x10DOTS  0x04

/** 5x8 dots character font */
#define LCD_5x8DOTS   0x00

/* Public Function Prototypes ------------------------------------------------*/

/**
  * @brief  Initializes the LCD with specified GPIO pins
  * @param  RS_Port, RS_Pin: Register Select port and pin
  * @param  RW_Port, RW_Pin: Read/Write port and pin
  * @param  EN_Port, EN_Pin: Enable port and pin
  * @param  D4_Port, D4_Pin: Data 4 port and pin
  * @param  D5_Port, D5_Pin: Data 5 port and pin
  * @param  D6_Port, D6_Pin: Data 6 port and pin
  * @param  D7_Port, D7_Pin: Data 7 port and pin
  */
void LCD_Init(
    GPIO_TypeDef* RS_Port, uint16_t RS_Pin,
    GPIO_TypeDef* RW_Port, uint16_t RW_Pin,
    GPIO_TypeDef* EN_Port, uint16_t EN_Pin,
    GPIO_TypeDef* D4_Port, uint16_t D4_Pin,
    GPIO_TypeDef* D5_Port, uint16_t D5_Pin,
    GPIO_TypeDef* D6_Port, uint16_t D6_Pin,
    GPIO_TypeDef* D7_Port, uint16_t D7_Pin
);

/**
  * @brief  Sends a command to the LCD
  * @param  cmd: Command to send
  */
void LCD_SendCommand(uint8_t cmd);

/**
  * @brief  Sends data to the LCD
  * @param  data: Data to send
  */
void LCD_SendData(uint8_t data);

/**
  * @brief  Displays a string on the LCD
  * @param  str: Pointer to the null-terminated string
  */
void LCD_SendString(char *str);

/**
  * @brief  Sets the cursor position
  * @param  row: Row number (0 to 3)
  * @param  column: Column number (0 to 15 for 16x2 LCD)
  */
void LCD_SetCursor(uint8_t row, uint8_t column);

/**
  * @brief  Clears the LCD display
  */
void LCD_Clear(void);

/**
  * @brief  Returns cursor to home position
  */
void LCD_Home(void);

/* Additional LCD Functions */
void LCD_DisplayOn(void);
void LCD_DisplayOff(void);
void LCD_CursorOn(void);
void LCD_CursorOff(void);
void LCD_BlinkOn(void);
void LCD_BlinkOff(void);
void LCD_ScrollLeft(void);
void LCD_ScrollRight(void);
void LCD_CustomChar(uint8_t location, uint8_t charmap[]);
void LCD_PrintNumber(int num);
void LCD_PrintFloat(float num, uint8_t decimals);
/////////////////////////////////////////////////////////
void LCD_FullDemo(uint32_t delay_ms);

#endif /* INC_RJ_ELEKTRONIK_HX711_LCD_H_ */
